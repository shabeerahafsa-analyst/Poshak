const CACHE_NAME = "kitchen-planner-v1";

const ASSETS = [
  "meal_planner.html",
  "manifest.json",
  "my-logo.png"
];

// Install – cache files
self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
  );
});

// Fetch – serve from cache when offline
self.addEventListener("fetch", event => {
  event.respondWith(
    caches.match(event.request).then(response => {
      return response || fetch(event.request);
    })
  );
});
